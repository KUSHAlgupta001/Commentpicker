async function fetchComments() {
    const videoUrl = document.getElementById('videoUrl').value;
    const videoId = extractVideoID(videoUrl);
    
    if (!videoId) {
        alert("Invalid YouTube URL");
        return;
    }

    const apiKey = "YOUR_YOUTUBE_API_KEY";  // Replace with your API key
    const url = `https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&videoId=${videoId}&key=${apiKey}&maxResults=50`;

    try {
        let response = await fetch(url);
        let data = await response.json();

        if (data.items) {
            window.comments = data.items.map(item => item.snippet.topLevelComment.snippet.textDisplay);
            document.getElementById("comments").innerHTML = comments.join("<br><br>");
        } else {
            alert("No comments found or API limit exceeded.");
        }
    } catch (error) {
        alert("Error fetching comments.");
    }
}

function pickRandomComment() {
    if (!window.comments || window.comments.length === 0) {
        alert("No comments available. Fetch comments first.");
        return;
    }
    const randomComment = window.comments[Math.floor(Math.random() * window.comments.length)];
    document.getElementById("winner").innerText = "Winner: " + randomComment;
}

function extractVideoID(url) {
    const match = url.match(/[?&]v=([^&]+)/);
    return match ? match[1] : null;
}
